/* ===========================
   DODONG SIMULATOR — script.js
   Purely fictional comedy sim.
=========================== */

// ---------- STATE ----------
let state = {
  phoneChecks: 0,
  phoneMeter: 2,
  crushMeter: 0,
  crushEvents: 0,
  cart: [],
  cartTotal: 0,
  rizz: 2,
  wallet: 100,
  followers: 0,
  unlocked: new Set()
};

// ---------- DOM REFS ----------
const checkCount = document.getElementById('checkCount');
const phoneMeter = document.getElementById('phoneMeter');
const phoneReaction = document.getElementById('phoneReaction');
const checkPhoneBtn = document.getElementById('checkPhoneBtn');

const crushMeter = document.getElementById('crushMeter');
const crushReaction = document.getElementById('crushReaction');
const crushBtn = document.getElementById('crushBtn');

const addItemBtn = document.getElementById('addItemBtn');
const cartList = document.getElementById('cartList');
const cartTotalEl = document.getElementById('cartTotal');

const achievementList = document.getElementById('achievementList');

const quoteBtn = document.getElementById('quoteBtn');
const quoteText = document.getElementById('quoteText');

const rizzValue = document.getElementById('rizzValue');
const walletValue = document.getElementById('walletValue');
const sleepValue = document.getElementById('sleepValue');
const cloutValue = document.getElementById('cloutValue');

const popupOverlay = document.getElementById('popupOverlay');
const popupText = document.getElementById('popupText');
const popupClose = document.getElementById('popupClose');
const confettiLayer = document.getElementById('confettiLayer');
const heroAvatar = document.getElementById('heroAvatar');

// ---------- CONTENT BANKS ----------
const phoneReactions = [
  "Licked the screen. No new messages. Worth it anyway.",
  "Refreshed the app 6 times in 4 seconds. Still nothing.",
  "Accidentally liked a photo from 2019. Panic ensues.",
  "Typed 'hey' then deleted it 14 times.",
  "Battery at 12% and he's still doomscrolling like a champion.",
  "Checked airplane mode was off. It was never on.",
  "Zoomed into a blurry photo for absolutely no reason.",
  "Read a message, didn't reply, closed the app anyway.",
];

const crushSightings = [
  "Andrea posted a selfie. Dodong screenshot it 'for reference'.",
  "Andrea liked a comment (not his). He is still proud somehow.",
  "Dodong practiced a comment in his notes app for 20 minutes.",
  "Andrea's new ad played on TV. Dodong paused to bow slightly.",
  "He renamed his phone hotspot 'AndreasFutureHusbandWiFi'.",
  "Dodong set a 6am alarm just to be first to like her next post.",
  "He drafted a DM. It said only 'hi'. He did not send it.",
  "Andrea followed a random fan account. Dodong reported it as 'suspicious'.",
];

const shopItems = [
  { name: "Inflatable flamingo pool float (indoor use only)", price: 799 },
  { name: "47-pack of phone cases, all the same design", price: 1290 },
  { name: "Glow-in-the-dark ceiling stars", price: 249 },
  { name: "A single left sock, novelty print", price: 99 },
  { name: "Ring light bigger than his room", price: 1599 },
  { name: "Fortune cookie bulk box (500 pcs)", price: 450 },
  { name: "Karaoke mic shaped like a banana", price: 599 },
  { name: "'World's Okayest Boyfriend' mug (single, unused)", price: 199 },
  { name: "Life-sized cardboard standee of a stock photo model", price: 2100 },
  { name: "Extremely specific fishing lure he will never use", price: 320 },
  { name: "Neck pillow shaped like instant noodles", price: 275 },
  { name: "USB-powered mini disco ball", price: 350 },
  { name: "Bubble wrap keychain, endless popping edition", price: 120 },
  { name: "A single roll of caution tape, no explanation given", price: 180 },
  { name: "Motivational wall decal that just says 'bawal umiyak'", price: 260 },
];

const quotes = [
  "\"Life is like a Shopee cart — 90% impulse, 10% regret, 0% returns.\"",
  "\"Sabi nila move on. Pero paano kung hindi pa nga tayo nag-start?\"",
  "\"I don't cry. My phone screen is just very reflective.\"",
  "\"Every notification is a chance at love. Every love is a chance at debt.\"",
  "\"Charot lang... pero seryoso.\"",
  "\"My love language is refreshing her profile 40 times a day.\"",
  "\"Wallet: empty. Heart: also empty. Cart: mysteriously full.\"",
  "\"I don't have a type. I have a targeted ad algorithm.\"",
  "\"Sleep is temporary, checking her last seen is forever.\"",
  "\"Hindi ako chronically online, ako lang yung laging naka-Wi-Fi sa buhay niya.\"",
];

const achievements = [
  { id: 'first_check', label: '📱 First Check — opened phone within 3 seconds of picking it up', cond: s => s.phoneChecks >= 1 },
  { id: 'neck_bend', label: '🦴 Text Neck Certified — checked phone 10+ times', cond: s => s.phoneChecks >= 10 },
  { id: 'menace', label: '👹 Certified Menace — checked phone 25+ times', cond: s => s.phoneChecks >= 25 },
  { id: 'first_sighting', label: '💘 Simp Initiate — witnessed 1 Andrea sighting', cond: s => s.crushEvents >= 1 },
  { id: 'super_fan', label: '🏆 Certified #1 Fan — witnessed 5 Andrea sightings', cond: s => s.crushEvents >= 5 },
  { id: 'delulu', label: '🌈 Full Delulu Mode — crush meter maxed out', cond: s => s.crushMeter >= 100 },
  { id: 'first_buy', label: '🛒 Impulse Initiate — added 1 cart item', cond: s => s.cart.length >= 1 },
  { id: 'broke', label: '💸 Financially Deceased — spent over ₱2000', cond: s => s.cartTotal >= 2000 },
  { id: 'bankrupt', label: '☠️ Total Bankruptcy Arc — wallet health at 0%', cond: s => s.wallet <= 0 },
  { id: 'wise', label: '🎤 Barangay Philosopher — asked for life advice 3 times', cond: s => s.quotesAsked >= 3 },
];
state.quotesAsked = 0;

// ---------- HELPERS ----------
function rand(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }

function showPopup(msg) {
  popupText.textContent = msg;
  popupOverlay.classList.add('active');
}
popupClose.addEventListener('click', () => popupOverlay.classList.remove('active'));
popupOverlay.addEventListener('click', (e) => {
  if (e.target === popupOverlay) popupOverlay.classList.remove('active');
});

function launchConfetti(count = 40) {
  const colors = ['#ff3ea5', '#ffd23f', '#7c3aed', '#ff7a3d', '#ff4d4d'];
  for (let i = 0; i < count; i++) {
    const piece = document.createElement('div');
    piece.className = 'confetti-piece';
    piece.style.left = Math.random() * 100 + 'vw';
    piece.style.background = rand(colors);
    piece.style.animationDuration = (2 + Math.random() * 2) + 's';
    piece.style.width = piece.style.height = (6 + Math.random() * 8) + 'px';
    confettiLayer.appendChild(piece);
    setTimeout(() => piece.remove(), 4200);
  }
}

function updateStatsBar() {
  rizzValue.textContent = clamp(state.rizz, 0, 100) + '%';
  walletValue.textContent = '₱' + clamp(state.wallet, 0, 100) + '%';
  cloutValue.textContent = state.followers + ' followers';
  const sleepStages = ["Pristine", "Questionable", "In Danger", "Gone", "Destroyed", "Mythical (nonexistent)"];
  const idx = clamp(Math.floor(state.phoneChecks / 5), 0, sleepStages.length - 1);
  sleepValue.textContent = sleepStages[idx];
}

function checkAchievements() {
  achievements.forEach(a => {
    if (!state.unlocked.has(a.id) && a.cond(state)) {
      state.unlocked.add(a.id);
      unlockAchievement(a);
    }
  });
}

function unlockAchievement(a) {
  if (achievementList.querySelector('.ach-locked')) {
    achievementList.innerHTML = '';
  }
  const li = document.createElement('li');
  li.className = 'ach-unlocked';
  li.textContent = a.label;
  achievementList.prepend(li);
  launchConfetti(25);
}

// ---------- PHONE OBSESSION ----------
checkPhoneBtn.addEventListener('click', () => {
  state.phoneChecks++;
  state.phoneMeter = clamp(state.phoneMeter + rand([6, 8, 10, 12]), 2, 100);
  state.rizz = clamp(state.rizz + (Math.random() > 0.7 ? 1 : 0), 0, 100);

  checkCount.textContent = state.phoneChecks;
  phoneMeter.style.width = state.phoneMeter + '%';
  phoneReaction.textContent = rand(phoneReactions);

  heroAvatar.textContent = rand(['📱🥴', '📱😵‍💫', '📱🫠', '📱🥲']);

  if (state.phoneMeter >= 100) {
    showPopup("PHONE OBSESSION MAXED OUT 🚨 Dodong has achieved perfect unity with his device. He is now legally part smartphone.");
  }

  updateStatsBar();
  checkAchievements();
});

// ---------- CRUSH METER ----------
crushBtn.addEventListener('click', () => {
  state.crushEvents++;
  state.crushMeter = clamp(state.crushMeter + rand([10, 15, 20]), 0, 100);
  state.followers = clamp(state.followers - rand([0, 1, 2]), 0, 99999);

  crushMeter.style.width = state.crushMeter + '%';
  crushReaction.textContent = rand(crushSightings);

  if (state.crushMeter >= 100) {
    showPopup("DELULU METER MAXED OUT 💗 Dodong has entered his final form: a man who refreshes one profile forever. Andrea remains unaware. As is tradition.");
  }

  updateStatsBar();
  checkAchievements();
});

// ---------- SHOPPING CART ----------
addItemBtn.addEventListener('click', () => {
  const item = rand(shopItems);
  state.cart.push(item);
  state.cartTotal += item.price;
  state.wallet = clamp(state.wallet - rand([3, 5, 8]), 0, 100);

  if (cartList.querySelector('.cart-empty')) cartList.innerHTML = '';

  const li = document.createElement('li');
  li.innerHTML = `<span>${item.name}</span><span>₱${item.price}</span>`;
  cartList.prepend(li);

  cartTotalEl.textContent = '₱' + state.cartTotal.toLocaleString();

  if (state.wallet <= 0) {
    showPopup("WALLET HEALTH: 0% 💀 Dodong's bank app just sent a follow-up text asking if he's okay. He is not okay. He is adding another item to cart.");
  }

  updateStatsBar();
  checkAchievements();
});

// ---------- QUOTE GENERATOR ----------
quoteBtn.addEventListener('click', () => {
  quoteText.textContent = rand(quotes);
  state.quotesAsked++;
  checkAchievements();
});

// ---------- INIT ----------
updateStatsBar();
